var searchData=
[
  ['packet_5fbuffer_5fsize',['PACKET_BUFFER_SIZE',['../_myo_bridge_8h.html#ab30af815d6e9494361629440f14e3716',1,'MyoBridge.h']]]
];
