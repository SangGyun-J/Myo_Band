var searchData=
[
  ['imu_5fmode',['imu_mode',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a94614e2be329e2cd75c92076cac53cce',1,'MYOHW_PACKED']]],
  ['imu_5fmode_5fnone',['IMU_MODE_NONE',['../_myo_bridge_8h.html#a54c22dd129ffbd60f8f85c70c2ed68b6ac831e89dbd09914bf12d2acba7203643',1,'MyoBridge.h']]],
  ['imu_5fmode_5fsend_5fall',['IMU_MODE_SEND_ALL',['../_myo_bridge_8h.html#a54c22dd129ffbd60f8f85c70c2ed68b6ab6766b40e015c6621e83e6a1ea015a17',1,'MyoBridge.h']]],
  ['imu_5fmode_5fsend_5fdata',['IMU_MODE_SEND_DATA',['../_myo_bridge_8h.html#a54c22dd129ffbd60f8f85c70c2ed68b6ad4d1fdbf0ab86e1d77d4b159a765191d',1,'MyoBridge.h']]],
  ['imu_5fmode_5fsend_5fevents',['IMU_MODE_SEND_EVENTS',['../_myo_bridge_8h.html#a54c22dd129ffbd60f8f85c70c2ed68b6ac4f2a099897ab68921f2127ac7ca9fab',1,'MyoBridge.h']]],
  ['imu_5fmode_5fsend_5fraw',['IMU_MODE_SEND_RAW',['../_myo_bridge_8h.html#a54c22dd129ffbd60f8f85c70c2ed68b6a157e21befbf5d816abf10e68c90d2cf0',1,'MyoBridge.h']]],
  ['imu_5fmotion_5ftap',['IMU_MOTION_TAP',['../_myo_bridge_8h.html#a8278027227ba7e129f30757d5ff5bff0a60b44df7443725972850fa95289e6665',1,'MyoBridge.h']]],
  ['imudatacharacteristic',['IMUDataCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a2595a3c29834f3cf80bb1184b217df05',1,'myohw.h']]],
  ['imudataservice',['ImuDataService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867af086dfb1aeaf7573af15bf94baca9043',1,'myohw.h']]],
  ['index',['index',['../struct_m_y_b_read_cmd__t.html#ac743a4f8f46b323e69d3c7be6e44b70c',1,'MYBReadCmd_t::index()'],['../struct_m_y_b_write_cmd__t.html#af04882d265149cc7dcb8dbab9a89a6c5',1,'MYBWriteCmd_t::index()'],['../struct_m_y_b_async_status_cmd__t.html#a70ea1aefa9c98b8ae3a4ff17792c1e94',1,'MYBAsyncStatusCmd_t::index()']]]
];
