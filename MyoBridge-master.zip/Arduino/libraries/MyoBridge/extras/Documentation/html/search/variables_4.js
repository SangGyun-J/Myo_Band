var searchData=
[
  ['emg_5fmode',['emg_mode',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a2f3600af28c9fc325e0ff51979bcfa23',1,'MYOHW_PACKED']]]
];
