var searchData=
[
  ['connectionstatustostring',['connectionStatusToString',['../group__utility__funcs.html#gacba3fc3a629cfe244feff21f521bff00',1,'MyoBridge']]]
];
