var searchData=
[
  ['unlockmyo',['unlockMyo',['../group__basic__funcs.html#gacf21fbfe35625c9b782dc890952d557e',1,'MyoBridge']]],
  ['update',['update',['../group__basic__funcs.html#ga085f3de45bc0667ea7263274874713ca',1,'MyoBridge']]]
];
