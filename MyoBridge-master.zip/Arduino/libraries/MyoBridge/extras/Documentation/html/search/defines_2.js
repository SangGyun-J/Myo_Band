var searchData=
[
  ['result_5fbuffer_5fsize',['RESULT_BUFFER_SIZE',['../_myo_bridge_8h.html#a4b89da90303d95ce654b7ad8a05daac9',1,'MyoBridge.h']]],
  ['rx_5fbuffer_5fsize',['RX_BUFFER_SIZE',['../_myo_bridge_8h.html#a739a2a1a0047c98ac1b18ecd25dac092',1,'MyoBridge.h']]]
];
