var searchData=
[
  ['functions_20for_20advanced_20usage',['Functions for Advanced Usage',['../group__advanced__funcs.html',1,'']]],
  ['functions_20for_20basic_20usage',['Functions for Basic Usage',['../group__basic__funcs.html',1,'']]]
];
