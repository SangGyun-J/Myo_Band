var searchData=
[
  ['begin',['begin',['../group__basic__funcs.html#ga362caf3b69a6979cd4e8ec4f7ed7fcd8',1,'MyoBridge']]],
  ['bridgeserial',['bridgeSerial',['../print_firmware_info_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;printFirmwareInfo.ino'],['../read_e_m_g_data_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;readEMGData.ino'],['../read_i_m_u_data_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;readIMUData.ino'],['../read_pose_data_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;readPoseData.ino']]]
];
