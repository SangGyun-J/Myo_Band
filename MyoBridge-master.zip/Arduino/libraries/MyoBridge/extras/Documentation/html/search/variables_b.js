var searchData=
[
  ['patch',['patch',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#ac34b55d7b945df27d348e323ae78b355',1,'MYOHW_PACKED']]],
  ['payload_5fsize',['payload_size',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a3b40747df7a523ea7d9cfa15efcaff3a',1,'MYOHW_PACKED']]],
  ['pdata',['pData',['../struct_m_y_b_write_cmd__t.html#ac2ffc625cdd3a23cfd987d404ca47fa6',1,'MYBWriteCmd_t::pData()'],['../struct_m_y_b_data_rsp__t.html#a148e7d3567f30da277cfb0fd78a26755',1,'MYBDataRsp_t::pData()']]],
  ['pose',['pose',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#a518831828d6864f3b025422598e5a845',1,'MYOHW_PACKED::MYOHW_PACKED']]]
];
