var searchData=
[
  ['accelerometer',['accelerometer',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a80303225b035b01bb28ed947bbd56e09',1,'MYOHW_PACKED']]],
  ['active_5fclassifier_5findex',['active_classifier_index',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a2440ecd58c509b14dc997c687401ac7c',1,'MYOHW_PACKED']]],
  ['active_5fclassifier_5ftype',['active_classifier_type',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a26b629cde07aed79f6a16dec52fda9f9',1,'MYOHW_PACKED']]],
  ['arm',['arm',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#ae9d296d714cece326fc3b4aa3528c0d4',1,'MYOHW_PACKED::MYOHW_PACKED::MYOHW_PACKED']]]
];
