var searchData=
[
  ['devicename',['DeviceName',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1aaacec5de803529515f571288cec049e1',1,'myohw.h']]]
];
