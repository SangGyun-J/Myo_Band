var group__myb__system__status =
[
    [ "MYB_STATUS_BUSY", "group__myb__system__status.html#gac8c22cc84f31cc67248de58570620d38", null ],
    [ "MYB_STATUS_CONNECTING", "group__myb__system__status.html#ga3e077e8115290b98a55d8277750d9b2e", null ],
    [ "MYB_STATUS_DISCOVERING", "group__myb__system__status.html#gaf2d9e63dcf3d3f292d2a167721ef0d34", null ],
    [ "MYB_STATUS_INIT", "group__myb__system__status.html#ga87275f01f8c8adba5f9a51725d68de45", null ],
    [ "MYB_STATUS_READY", "group__myb__system__status.html#ga351bb0d040687b21af8dffa4af5d705b", null ],
    [ "MYB_STATUS_SCANNING", "group__myb__system__status.html#gacd43b5d5acd1b996697141195750f0d2", null ],
    [ "MYB_STATUS_UNKNOWN", "group__myb__system__status.html#ga88fe32bae49025e47b750a637e2e27f8", null ]
];