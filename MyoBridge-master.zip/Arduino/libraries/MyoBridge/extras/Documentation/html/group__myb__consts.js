var group__myb__consts =
[
    [ "System Status Constants", "group__myb__system__status.html", "group__myb__system__status" ],
    [ "Serial Command Types", "group__myb__serial__commands.html", "group__myb__serial__commands" ],
    [ "Serial Packet Types", "group__myb__serial__types.html", "group__myb__serial__types" ],
    [ "MYB_MODULE_CONNECT_TIMEOUT", "group__myb__consts.html#gab810e1004bc24b502fdbe130d5e7bc74", null ],
    [ "MYB_RETRY_TIMEOUT", "group__myb__consts.html#gabd509c5dcab58004ca4ee0d647817dfb", null ]
];