var group__advanced__funcs =
[
    [ "disableAllMessages", "group__advanced__funcs.html#ga1d5259d0651474d18909eb2f5c24b36b", null ],
    [ "doConfirmedWrite", "group__advanced__funcs.html#gaea589b1f77b598db320ca0c24bf42ecb", null ],
    [ "doPersistentRead", "group__advanced__funcs.html#gaeb246fdfa656de14bd345d80762f54eb", null ],
    [ "enableAllMessages", "group__advanced__funcs.html#ga52ae472dcf995d2806e7eb190f4b214b", null ],
    [ "sendCommand", "group__advanced__funcs.html#ga38ee56d816b6016b2eefc3581c6eb1ee", null ]
];