var print_firmware_info_8ino =
[
    [ "bridgeSerial", "print_firmware_info_8ino.html#ad9fb93a907416d9117978fb354112691", null ],
    [ "loop", "print_firmware_info_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "printConnectionStatus", "print_firmware_info_8ino.html#a7bd552e2fe06672d581e53cee57b5097", null ],
    [ "setup", "print_firmware_info_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "bridge", "print_firmware_info_8ino.html#a1bbd37be74a749453817a3d174cd31b0", null ]
];