var struct_m_y_b_rsp_hdr__t =
[
    [ "len", "struct_m_y_b_rsp_hdr__t.html#abd6992e35048a09732a7b5533e77153e", null ],
    [ "type", "struct_m_y_b_rsp_hdr__t.html#a786acdf67dc51092394d16010d79d43c", null ]
];