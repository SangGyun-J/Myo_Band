var group__basic__funcs =
[
    [ "begin", "group__basic__funcs.html#ga362caf3b69a6979cd4e8ec4f7ed7fcd8", null ],
    [ "disablePoseData", "group__basic__funcs.html#gada461094adb8f2aa68bd29476b533c6c", null ],
    [ "disableSleep", "group__basic__funcs.html#gac67b7cf02b451c5bc94dccc3730a404d", null ],
    [ "enablePoseData", "group__basic__funcs.html#ga619d927ea7aca5333685717869db2f0d", null ],
    [ "enableSleep", "group__basic__funcs.html#gae9f63a6013004c894fe365343933ba61", null ],
    [ "getBatteryLevel", "group__basic__funcs.html#ga68e5ac3315ac5e8f4677eaafdb088bb7", null ],
    [ "getFirmwareMajor", "group__basic__funcs.html#ga356267611fd901901a70413f45e192e0", null ],
    [ "getFirmwareMinor", "group__basic__funcs.html#gaf26706bf32f6cab745b5bef9b968c0b7", null ],
    [ "getFirmwarePatch", "group__basic__funcs.html#gafc70a718c92b0162fd43d10ffc1fbe5c", null ],
    [ "getHardwareAddress", "group__basic__funcs.html#ga5e2132f6927345e166bd187f9ee6123d", null ],
    [ "getHardwareRevision", "group__basic__funcs.html#gaf018a57459556dae7c1d153236ae65a0", null ],
    [ "getUnlockPose", "group__basic__funcs.html#gab850c1decfbb452766f8e17e9c2599e9", null ],
    [ "lockMyo", "group__basic__funcs.html#gad0dae46cd6832633fd24681131d504a6", null ],
    [ "MyoBridge", "group__basic__funcs.html#gad0c33d21c91c3d25255a52cde47e925d", null ],
    [ "setEMGMode", "group__basic__funcs.html#ga6d564f122e4fd5e3f3d968826ad21359", null ],
    [ "setIMUMode", "group__basic__funcs.html#ga2e522738fcd9353c2e2d55a4894b6fad", null ],
    [ "unlockMyo", "group__basic__funcs.html#gacf21fbfe35625c9b782dc890952d557e", null ],
    [ "update", "group__basic__funcs.html#ga085f3de45bc0667ea7263274874713ca", null ],
    [ "vibrate", "group__basic__funcs.html#ga023c11b4bead1fd3f512ad101fb25a93", null ]
];