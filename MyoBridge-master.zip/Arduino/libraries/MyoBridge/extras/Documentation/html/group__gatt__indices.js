var group__gatt__indices =
[
    [ "MyoCharacteristicIndex_t", "group__gatt__indices.html#gac9c0ba99b06c050e5a4e8df4c7f8c506", [
      [ "MYO_SERV_CONTROL", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a32cb28998f3e9cb126852a005d26da8d", null ],
      [ "MYO_CHAR_INFO", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506ae693ec3f564132fdfe92e4bf4e3f8505", null ],
      [ "MYO_CHAR_FIRMWARE", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506ad162f6a5d9476ae5017a23e4d4d17b4c", null ],
      [ "MYO_CHAR_COMMAND", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a6df200e313b1009e7926618745330c91", null ],
      [ "MYO_SERV_IMU_DATA", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a7d4945d96a75c229dfb028f34f898f7d", null ],
      [ "MYO_CHAR_IMU_DATA", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506aa75bb24967040dabe333876e13eeaf73", null ],
      [ "MYO_CHAR_IMU_EVENTS", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a90f1afbf569fcc2af3f92718b9ca6182", null ],
      [ "MYO_SERV_CLASSIFIER", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506aa825087d56b9dc6f80033b70a8794dcb", null ],
      [ "MYO_CHAR_CLASSIFIER_EVENTS", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506aac22c740f075780db65aed8f4cba6243", null ],
      [ "MYO_SERV_EMG", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a174329e627a2584c28928099204c9d57", null ],
      [ "MYO_CHAR_EMG_0", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a391dd627940d39af4bcea205cba4e8ee", null ],
      [ "MYO_CHAR_EMG_1", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506ad56d9640df0c19713499dc332f8dc30b", null ],
      [ "MYO_CHAR_EMG_2", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a15638ba022a59ce01e17bb7900931022", null ],
      [ "MYO_CHAR_EMG_3", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506adafff0f7a23bb5998a90f3d16db62f4b", null ],
      [ "MYO_SERV_BATTERY", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a85ce93cb1d071e5c428f76d85530ceab", null ],
      [ "MYO_CHAR_BATTERY_LEVEL", "group__gatt__indices.html#ggac9c0ba99b06c050e5a4e8df4c7f8c506a079222ae35e0285978df13db0f3ccba8", null ]
    ] ]
];