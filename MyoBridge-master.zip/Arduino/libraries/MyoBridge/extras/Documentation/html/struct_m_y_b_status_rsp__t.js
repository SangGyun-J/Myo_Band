var struct_m_y_b_status_rsp__t =
[
    [ "hdr", "struct_m_y_b_status_rsp__t.html#a8bf6b8809d9cb64a27e00c925b18e421", null ],
    [ "status", "struct_m_y_b_status_rsp__t.html#a9e77fcc606195fd193673b676566397b", null ]
];