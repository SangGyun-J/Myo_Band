var group__myb__osal__structs =
[
    [ "MYBOSALDataRsp_t", "struct_m_y_b_o_s_a_l_data_rsp__t.html", [
      [ "hdr", "struct_m_y_b_o_s_a_l_data_rsp__t.html#ad4e9191a502e9883051132a8501b6c9c", null ],
      [ "rsp", "struct_m_y_b_o_s_a_l_data_rsp__t.html#a8c0af871695c957e01aaabbb75c8aa27", null ]
    ] ],
    [ "MYBOSALPingRsp_t", "struct_m_y_b_o_s_a_l_ping_rsp__t.html", [
      [ "hdr", "struct_m_y_b_o_s_a_l_ping_rsp__t.html#ad4e9191a502e9883051132a8501b6c9c", null ],
      [ "rsp", "struct_m_y_b_o_s_a_l_ping_rsp__t.html#a54e7e78b9bbe2f1381e453a800f9332f", null ]
    ] ],
    [ "MYBOSALSerialPacket_t", "struct_m_y_b_o_s_a_l_serial_packet__t.html", [
      [ "hdr", "struct_m_y_b_o_s_a_l_serial_packet__t.html#ad4e9191a502e9883051132a8501b6c9c", null ],
      [ "len", "struct_m_y_b_o_s_a_l_serial_packet__t.html#a8ccac76f35f79d74917e1c5dd6f69fea", null ],
      [ "pData", "struct_m_y_b_o_s_a_l_serial_packet__t.html#aea3016a10fc81479fa9f31e919029470", null ]
    ] ]
];