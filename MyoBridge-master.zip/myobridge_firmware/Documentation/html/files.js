var files =
[
    [ "myo_gatt.c", "myo__gatt_8c.html", "myo__gatt_8c" ],
    [ "myo_gatt.h", "myo__gatt_8h.html", "myo__gatt_8h" ],
    [ "MyoBridge.c", "_myo_bridge_8c.html", "_myo_bridge_8c" ],
    [ "MyoBridge.h", "_myo_bridge_8h.html", "_myo_bridge_8h" ],
    [ "MyoBridge_Main.c", "_myo_bridge___main_8c.html", "_myo_bridge___main_8c" ],
    [ "myohw.h", "myohw_8h.html", "myohw_8h" ],
    [ "OSAL_MyoBridge.c", "_o_s_a_l___myo_bridge_8c.html", "_o_s_a_l___myo_bridge_8c" ],
    [ "serialInterface.c", "serial_interface_8c.html", "serial_interface_8c" ],
    [ "serialInterface.h", "serial_interface_8h.html", "serial_interface_8h" ]
];