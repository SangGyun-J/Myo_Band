var modules =
[
    [ "MyoBridge GATT Data Structures", "group__gatt__types.html", "group__gatt__types" ],
    [ "MyoBridge Control Constants", "group__myb__consts.html", "group__myb__consts" ],
    [ "MyoBridge Data Structures", "group__myb__data__structs.html", "group__myb__data__structs" ],
    [ "Myo Hardware Data Structures", "group__myo__hardware.html", "group__myo__hardware" ],
    [ "MyoBridge Serial Interface Functions", "group__serial__functions.html", "group__serial__functions" ]
];