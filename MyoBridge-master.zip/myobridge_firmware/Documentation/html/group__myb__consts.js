var group__myb__consts =
[
    [ "System Status Constants", "group__myb__system__status.html", "group__myb__system__status" ],
    [ "OSAL Message Events", "group__myb__osal__events.html", "group__myb__osal__events" ],
    [ "MyoBridge Application Events", "group__myb__task__events.html", "group__myb__task__events" ],
    [ "Serial Command Types", "group__myb__serial__commands.html", "group__myb__serial__commands" ],
    [ "Serial Packet Types", "group__myb__serial__types.html", "group__myb__serial__types" ]
];