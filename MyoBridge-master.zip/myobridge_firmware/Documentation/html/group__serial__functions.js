var group__serial__functions =
[
    [ "printd", "group__serial__functions.html#ga9769e79c4182b72f786c3b293c244687", null ],
    [ "prints", "group__serial__functions.html#ga9ce8e4fba53bf524615b5a51dc91fa72", null ],
    [ "sendDataRsp", "group__serial__functions.html#gaf8cfdc0c2e686568314e5c65d2114de7", null ],
    [ "sendPingRsp", "group__serial__functions.html#ga72cee0de6367b12da1df1a9a9ea4cd89", null ],
    [ "sendStatusRsp", "group__serial__functions.html#ga7f1e6ef8f4ea9abe0b938d0a20bc0157", null ]
];