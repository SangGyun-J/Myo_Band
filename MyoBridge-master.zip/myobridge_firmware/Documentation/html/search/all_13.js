var searchData=
[
  ['x',['x',['../structmyohw__imu__data__t.html#a3eea9b15d2280871010515d769d48f38',1,'myohw_imu_data_t']]],
  ['x_5fdirection',['x_direction',['../structmyohw__classifier__event__t.html#a28dd3aec4cf8a9080794ddb926c5d6b8',1,'myohw_classifier_event_t']]]
];
