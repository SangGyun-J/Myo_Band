var searchData=
[
  ['gatt_5faction_5fstate',['gatt_action_state',['../myo__gatt_8c.html#aad038fb553754f5743fd74e8b11f6b71',1,'myo_gatt.c']]],
  ['generate_5ffull_5fuuid',['generate_full_uuid',['../myo__gatt_8c.html#a529df8dad9a6d27f619ab480ddc50877',1,'myo_gatt.c']]],
  ['getgattstate',['getGATTState',['../myo__gatt_8c.html#a4fc5b11ad45880991db689dd6a2828f7',1,'getGATTState():&#160;myo_gatt.c'],['../myo__gatt_8h.html#a4fc5b11ad45880991db689dd6a2828f7',1,'getGATTState():&#160;myo_gatt.c']]],
  ['gyroscope',['gyroscope',['../structmyohw__imu__data__t.html#ac76f49f99f66c1ba6ac6c3bb77298492',1,'myohw_imu_data_t']]]
];
