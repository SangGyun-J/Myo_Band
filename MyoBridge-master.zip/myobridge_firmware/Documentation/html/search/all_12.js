var searchData=
[
  ['w',['w',['../structmyohw__imu__data__t.html#a1e11b8ca2bafa5d2633e9b91cf734157',1,'myohw_imu_data_t']]],
  ['writechar',['writeChar',['../myo__gatt_8c.html#a83bee023d8548d4fb96606cd0f428381',1,'writeChar(uint8 MyoBridge_TaskID, uint16 myo_conn_handle, uint8 *pCommand, uint8 len, uint16 handle):&#160;myo_gatt.c'],['../myo__gatt_8h.html#a83bee023d8548d4fb96606cd0f428381',1,'writeChar(uint8 MyoBridge_TaskID, uint16 myo_conn_handle, uint8 *pCommand, uint8 len, uint16 handle):&#160;myo_gatt.c']]],
  ['writecharbyindex',['writeCharByIndex',['../myo__gatt_8c.html#a39d1f4205e3e4e9db2af120497bb9ed5',1,'writeCharByIndex(uint8 MyoBridge_TaskID, uint16 myo_conn_handle, uint8 *pCommand, uint8 len, MyoCharacteristicIndex_t index):&#160;myo_gatt.c'],['../myo__gatt_8h.html#a39d1f4205e3e4e9db2af120497bb9ed5',1,'writeCharByIndex(uint8 MyoBridge_TaskID, uint16 myo_conn_handle, uint8 *pCommand, uint8 len, MyoCharacteristicIndex_t index):&#160;myo_gatt.c']]]
];
