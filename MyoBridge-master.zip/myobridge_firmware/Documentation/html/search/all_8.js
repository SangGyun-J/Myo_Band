var searchData=
[
  ['imu_5fmode',['imu_mode',['../structmyohw__command__set__mode__t.html#a87e344155e99dd04e24acef75bd745c7',1,'myohw_command_set_mode_t']]],
  ['imudata',['imuData',['../struct_myo_handles__t.html#a27dd532525043f18660d127f4450be13',1,'MyoHandles_t']]],
  ['imudatacharacteristic',['IMUDataCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a2595a3c29834f3cf80bb1184b217df05',1,'myohw.h']]],
  ['imudataservice',['ImuDataService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867af086dfb1aeaf7573af15bf94baca9043',1,'myohw.h']]],
  ['imuevents',['imuEvents',['../struct_myo_handles__t.html#acb785227153ad101752e9684797ff103',1,'MyoHandles_t']]],
  ['imuserviceend',['imuServiceEnd',['../struct_myo_handles__t.html#a46128bad97b903402990b4d3a73ce4c4',1,'MyoHandles_t']]],
  ['imuservicestart',['imuServiceStart',['../struct_myo_handles__t.html#a8e983e27f43fdfb0a934b73ebe2abea7',1,'MyoHandles_t']]],
  ['index',['index',['../struct_m_y_b_read_cmd__t.html#ab9f50676c9071731dc96f5ed95603066',1,'MYBReadCmd_t::index()'],['../struct_m_y_b_write_cmd__t.html#ab9f50676c9071731dc96f5ed95603066',1,'MYBWriteCmd_t::index()'],['../struct_m_y_b_async_status_cmd__t.html#ab9f50676c9071731dc96f5ed95603066',1,'MYBAsyncStatusCmd_t::index()']]],
  ['index_5fcache',['index_cache',['../myo__gatt_8c.html#a167a946376df624048d839e524e132a1',1,'myo_gatt.c']]]
];
