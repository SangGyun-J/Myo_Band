var searchData=
[
  ['tap_5fcount',['tap_count',['../structmyohw__motion__event__t.html#ad2b9f54d9ea28533dffaf0a404a51720',1,'myohw_motion_event_t']]],
  ['tap_5fdirection',['tap_direction',['../structmyohw__motion__event__t.html#a34b13103641896a11b89ef8a96264b44',1,'myohw_motion_event_t']]],
  ['tasksarr',['tasksArr',['../_o_s_a_l___myo_bridge_8c.html#aa0bf3a98b2f5dc74f19d24d0f63a2b68',1,'OSAL_MyoBridge.c']]],
  ['taskscnt',['tasksCnt',['../_o_s_a_l___myo_bridge_8c.html#a1c008ff9f92b98c69fc68590ff42f15a',1,'OSAL_MyoBridge.c']]],
  ['tasksevents',['tasksEvents',['../_o_s_a_l___myo_bridge_8c.html#ae0c7891223baf95ee28a0dcc4f0fd298',1,'OSAL_MyoBridge.c']]],
  ['type',['type',['../struct_m_y_b_rsp_hdr__t.html#a0d5276797b2358f6093607c68006bde8',1,'MYBRspHdr_t::type()'],['../structmyohw__command__vibrate__t.html#a0d5276797b2358f6093607c68006bde8',1,'myohw_command_vibrate_t::type()'],['../structmyohw__command__unlock__t.html#a0d5276797b2358f6093607c68006bde8',1,'myohw_command_unlock_t::type()'],['../structmyohw__command__user__action__t.html#a0d5276797b2358f6093607c68006bde8',1,'myohw_command_user_action_t::type()'],['../structmyohw__motion__event__t.html#a0d5276797b2358f6093607c68006bde8',1,'myohw_motion_event_t::type()'],['../structmyohw__classifier__event__t.html#a0d5276797b2358f6093607c68006bde8',1,'myohw_classifier_event_t::type()']]]
];
