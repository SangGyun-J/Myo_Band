var searchData=
[
  ['batterylevel',['batteryLevel',['../struct_myo_handles__t.html#ac61684ca4d1fe9933dc1c5a794de9b03',1,'MyoHandles_t']]],
  ['batterylevelcharacteristic',['BatteryLevelCharacteristic',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1a5dc0cfdfaa7817966f1e86aa36bf5670',1,'myohw.h']]],
  ['batteryservice',['BatteryService',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1a3c3085f75abeb351af41db8bb8c93e26',1,'myohw.h']]],
  ['batteryserviceend',['batteryServiceEnd',['../struct_myo_handles__t.html#a5014bd82bdeb318c658126aee113ca82',1,'MyoHandles_t']]],
  ['batteryservicestart',['batteryServiceStart',['../struct_myo_handles__t.html#a6d9e1e4bf0d70c4a9c75430ea3afab55',1,'MyoHandles_t']]],
  ['buffer_5foffset',['buffer_offset',['../serial_interface_8c.html#a1dce7a4fad08a2aa738ab99791b310af',1,'serialInterface.c']]]
];
